# =========================
# app.py
# =========================

import streamlit as st
import re
from PIL import Image
import pytesseract

# OPTIONAL: Gemini (can comment if quota issues)
import google.generativeai as genai

# =========================
# CONFIG
# =========================

st.set_page_config(
    page_title="AI Financial Document Intelligence",
    page_icon="💼",
    layout="centered"
)

pytesseract.pytesseract.tesseract_cmd = "/opt/homebrew/bin/tesseract"

# Uncomment & add key only if needed
# genai.configure(api_key="YOUR_GEMINI_API_KEY")
# model = genai.GenerativeModel("gemini-1.5-flash")

# =========================
# UI HEADER
# =========================

st.markdown(
    """
    <h1 style="text-align:center;">💼 AI Financial Document Intelligence</h1>
    <p style="text-align:center; color:gray;">
    Upload Salary Slips, Bank Statements, or Utility Bills and extract insights instantly
    </p>
    """,
    unsafe_allow_html=True
)

st.divider()

# =========================
# OCR FUNCTION
# =========================

def run_ocr(uploaded_file):
    image = Image.open(uploaded_file)
    text = pytesseract.image_to_string(image)
    return text

# =========================
# CLEAN TEXT
# =========================

def clean_text(text):
    text = text.lower()
    text = re.sub(r"\s+", " ", text)
    return text

# =========================
# EXTRACTION FUNCTIONS
# =========================

def extract_salary(text):
    """
    OCR-robust salary extractor.
    Priority:
    1. Net Pay (if readable)
    2. Total Earnings (fallback)
    """

    text = text.lower().replace(",", "")

    # 1️⃣ Try NET PAY (very loose)
    net_patterns = [
        r"net\s*pay[^0-9]{0,30}(\d+\.?\d{0,2})",
        r"netpay[^0-9]{0,30}(\d+\.?\d{0,2})"
    ]

    for p in net_patterns:
        match = re.search(p, text)
        if match:
            return f"Rs. {match.group(1)}"

    # 2️⃣ Fallback → TOTAL EARNINGS (very reliable in OCR)
    match = re.search(
        r"total\s*earnings[^0-9]{0,30}(\d+\.?\d{0,2})",
        text
    )
    if match:
        return f"Rs. {match.group(1)}"

    return None

def extract_bank_balance(text):
    matches = re.findall(
        r"(balance|closing|available)[^0-9]{0,20}([\d,]+\.\d{2})",
        text
    )
    if matches:
        return f"INR {matches[-1][1]}"
    
    numbers = re.findall(r"\b\d{1,3}(?:,\d{3})*\.\d{2}\b", text)
    large = [float(n.replace(",", "")) for n in numbers if float(n.replace(",", "")) >= 1000]
    if large:
        return f"INR {large[-1]:.2f}"
    return None

def extract_utility_amount(text):
    match = re.search(r"total\s*amount[^0-9]{0,15}([\d,]+(?:\.\d{2})?)", text)
    if match:
        return match.group(1)
    
    match = re.search(r"current\s*charges[^0-9]{0,15}([\d,]+(?:\.\d{2})?)", text)
    if match:
        return match.group(1)
    return None

# =========================
# GEMINI EXPLANATION (OPTIONAL)
# =========================

def generate_explanation(value, doc_type, context):
    prompt = f"""
You are an AI assistant explaining extracted financial values.

Document Type: {doc_type}
Extracted Value: {value}

Explain clearly where this value comes from in the document.
"""
    response = model.generate_content(prompt)
    return response.text.strip()

# =========================
# MAIN INPUTS
# =========================

doc_type = st.selectbox(
    "Select Document Type",
    ["Salary Slip", "Bank Statement", "Utility Bill"]
)

uploaded_file = st.file_uploader(
    "📂 Upload Document",
    type=["png", "jpg", "jpeg"]
)

# =========================
# PROCESS
# =========================

if uploaded_file:
    st.divider()
    st.subheader("📄 Uploaded Document Preview")
    st.image(uploaded_file, use_column_width=True)

    with st.spinner("Running OCR..."):
        raw_text = run_ocr(uploaded_file)
        cleaned = clean_text(raw_text)

    st.subheader("🧾 Extracted Text (Preview)")
    st.text(cleaned[:1000])

    st.divider()
    st.subheader("🔍 Extracted Information")

    value = None

    if doc_type == "Salary Slip":
        value = extract_salary(cleaned)
        label = "Net Salary"

    elif doc_type == "Bank Statement":
        value = extract_bank_balance(cleaned)
        label = "Current Balance"

    elif doc_type == "Utility Bill":
        value = extract_utility_amount(cleaned)
        label = "Total Bill Amount"

    if value:
        st.success(f"**{label}: {value}**")

        # OPTIONAL Gemini explanation
        # explanation = generate_explanation(value, doc_type, cleaned)
        # st.info(explanation)

    else:
        st.warning("Value not found in the document.")

# =========================
# FOOTER
# =========================

st.divider()
st.markdown(
    "<p style='text-align:center; color:gray;'>Built with OCR, RAG principles & Generative AI</p>",
    unsafe_allow_html=True
)